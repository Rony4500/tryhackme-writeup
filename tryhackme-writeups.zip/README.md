# TryHackMe Room Writeups

This repository contains my personal walkthroughs of the TryHackMe rooms I have completed.

## ✅ Completed Rooms

- [Pickle Rick](./Pickle-Rick.md)
- [Basic Pentesting](./Basic-Pentesting.md)
- [Vulnversity](./Vulnversity.md)

> These writeups are for educational and documentation purposes only.
